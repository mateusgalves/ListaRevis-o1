/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva5;

import java.util.Scanner;

/**
 *
 * @author Home
 */
public class Novo extends Imovel {
    Imovel imovel = new Imovel();
    public double adicional(){
        Scanner input = new Scanner(System.in);
        double qtd = input.nextDouble();
        super.setPreco(getPreco() + qtd);
        System.out.println(qtd);
        return qtd;
        
    }
    
}
