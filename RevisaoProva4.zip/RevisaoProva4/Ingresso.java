/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva4;

/**
 *
 * @author Home
 */
public class Ingresso {
    protected double valor;

    public Ingresso(double valor) {
        this.valor = valor;
    }
    
    public double imprimeValor(){
        return valor;
        
    }
    
}




