/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva4;

/**
 *
 * @author Home
 */
public class CamaroteSuperior extends Ingresso{
    public double Adicional;

    public CamaroteSuperior(double valor) {
        super(valor);
    }

    

    public double getAdicional() {
        return Adicional;
    }

    public void setAdicional(double Adicional) {
        this.Adicional = Adicional;
    }
    public double retonarValorSup(){
        valor = valor + Adicional;
        return  valor;
    }
    
    
    
}
