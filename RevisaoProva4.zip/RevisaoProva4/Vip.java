/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva4;

/**
 *
 * @author Home
 */
public class Vip extends Ingresso{
    private double valorAd;
    
    public Vip(double valor) {
        super(valor);
    }
    
    public double ImprimeValor (double valor){
        valor = valor + valorAd;
        return valor;
        
    }
    
}
