/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva3;

/**
 *
 * @author Home
 */
public class Funcionario {
      private String matricula;

    public String GetMatricula() {
        return matricula;
    }

    public void exibeDados() {
        System.out.println("Matrícula do Funcionário" + matricula);
    }

}
    
