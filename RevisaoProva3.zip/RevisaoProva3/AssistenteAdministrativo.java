/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva3;

/**
 *
 * @author Home
 */
public class AssistenteAdministrativo extends {
    

    public void exibeDados(){
        super.exibeDados();
        System.out.println("Turno: " + getTurno());
        if(getTurno().equalsIgnoreCase("Noturno")){
            System.out.println("Adcional Noturno: R$ " + (getSalario()*0.3));
        }
        else{
            System.out.println("Sem adcional noturno");
        }
    }

    private double getSalario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private Object getTurno() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }




}
