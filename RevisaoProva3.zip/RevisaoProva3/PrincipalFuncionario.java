/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva3;

/**
 *
 * @author Home
 */
public class PrincipalFuncionario {
     public static void main(String[] args) {


        Funcionario gerente = new Gerente();
        Assistente tecnico = new AssistenteTecnico();
        Assistente administrativo = new AssistenteAdministrativo();


        gerente.setCodigoCadastro(1);
        gerente.setNome("Osvaldo");
        gerente.setSalario(4000);

        tecnico.setCodigoCadastro(35);
        tecnico.setNome("Samuel");
        tecnico.setMatricula(01);
        tecnico.setSalario(1800);

        administrativo.setCodigoCadastro(78);
        administrativo.setNome("Gregory");
        administrativo.setMatricula(02);
        administrativo.setSalario(1200);
        administrativo.setTurno("Noturno");

        System.out.println("\nGerente: ");
        gerente.exibeDados();
        System.out.println("\nAssistente técnico: ");
        tecnico.exibeDados();
        System.out.println("\nAssistente Admnistrativo: ");
        administrativo.exibeDados();


    }


    
}
