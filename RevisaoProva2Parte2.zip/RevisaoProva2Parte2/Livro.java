/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva2Parte2;

/**
 *
 * @author Home
 */
public class Livro extends Produto {
    
    public String autor;

    public Livro(String autor) {
        this.autor = autor;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
    
    public String ImprimeLivro (){
        return setAutor(getAutor);
    }
    
}
