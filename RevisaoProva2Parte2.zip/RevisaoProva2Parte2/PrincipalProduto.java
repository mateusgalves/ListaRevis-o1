/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva2Parte2;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Home
 */
public class PrincipalProduto {
    import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Home
 */
public class PrincipalProduto {

    public static void main(String[] args) {

        ArrayList<Produto> mouse = new ArrayList<Produto>();
        ArrayList<Produto> livro = new ArrayList<Produto>();
      
        
        

        int txt = 0;
     
      
            txt = Integer.parseInt(JOptionPane.showInputDialog(null, "1.Livro\n2.Mouse. sair"));
            if (txt == 1) {
                String nome = JOptionPane.showInputDialog("Nome do Livro: ");
                String autor = Au;
      
                Livro.setAutor(Au);
              

            }
            if (txt == 2) {
                String Mouse = JOptionPane.showInputDialog("Tipo do Mouse: ");
                          
                Mouse.setMouse(mouse);
               

            }

            

        } while (txt != 5);

    }
}

    
}
