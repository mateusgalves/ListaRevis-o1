/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva2;

/**
 *
 * @author Home
 */


public interface CarbonFootprint {
	double getCarbonFootprint(); //Recebe o carbon footprint(pegada de carbono)
}
    

