/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RevisaoProva6.questoA;

import javax.swing.JOptionPane;

/**
 *
 * @author Home
 */
public class AssistenteAdm {
    public String nome;
    public int matricula;

    public AssistenteAdm() {
        this.mat1 = JOptionPane.showInputDialog("Mat:");
        this.<error> = nome;
    }
    
    public String ImprimirNome(){
        this.nome = nome;
        return nome;
    }
    
    public int ImprimirMat(){
        this.matricula = matricula;
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }
    String nome1 = JOptionPane.showInputDialog("Nome:");
    String mat1;
    AssistenteAdm a1 = new AssistenteAdm();
                       
}

