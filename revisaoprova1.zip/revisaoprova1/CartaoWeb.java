/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaoprova1;

/**
 *
 * @author Home
 */
public abstract class CartaoWeb {
    protected String destinatario;

    public CartaoWeb() {
        
    }
    
    
    
    
  //cria o metodo abstrato RetornarMensagem;  
    public void RetornarMensagem (String remetente){
        this.destinatario = destinatario;
        
    }
}