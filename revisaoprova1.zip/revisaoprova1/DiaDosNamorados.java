/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaoprova1;

import javax.swing.JOptionPane;

/**
 *
 * @author Home
 */
public class DiaDosNamorados extends CartaoWeb{
    
    public String nomeDestinatario;

    public String getNomeDestinatario() {
        return nomeDestinatario;
    }

    public void setNomeDestinatario(String nomeDestinatario) {
        this.nomeDestinatario = nomeDestinatario;
    }
    
    
    
   //criando o metodo construtor para receber o nome do destinatario. 
    public DiaDosNamorados (String nomeDestinatario){
        this.nomeDestinatario = nomeDestinatario;
        
    }
    
    /**
     *
     * @param nomeDestinatario
     */
    public String RetornarMensagem (){
       return JOptionPane.showInputDialog("DESTINO: ");
   }
        
    }
    
    
    
    
    

